class Combustivel {
  String name;
  double price;
  
  Combustivel({
    required this.name,
    required this.price,
  });
}
