package com.example.projeto_integrador_fatec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
